package zombiewar;

public class ZombieWar {
    
    public static void main(String[] args) {
        
    }
}
